import React from "react";
import './aboutUs.css'


const AboutUs = () => {
    return(
        <div className="aboutUs">
            About Us
        </div>
    )
}


export default AboutUs