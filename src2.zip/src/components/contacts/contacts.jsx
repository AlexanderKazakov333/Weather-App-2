import React from 'react';
import './contacsts.css'

const Contacts = () => {
  return (
    <div className='contacts'>
        Конакты
    </div>
  );
};

export default Contacts;