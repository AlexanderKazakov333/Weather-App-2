import React from "react";
import './main.css';

const Main = ({setCity, getWeather, weather, isLoading, isActive,}) => {

  return (
      <div className="main">

        <div>
          <input type="text" className="input-city" placeholder='Введите город' onChange={(event) => setCity(event.target.value)}/>
          <input type="button" className="button-city" value='Узнать погоду' onClick={getWeather}/>
        </div>


        

        <div className="weather">

        <div className="town-country">
        {   isActive &&
        <div>
          {isLoading ?
            <div></div>
            :
            <div className="country">
              <span>Страна:</span> {weather.location.country}
            </div>
          }
        </div>
      }


      

      {   isActive &&
        <div>
          {isLoading ?
            <div></div>
            :
            <div>
              <span>Город:</span> {weather.location.name}
            </div>
          }
        </div>
      }


        </div>



        

      {   isActive ?
        <div>
          {isLoading ?
            <div className="loading">Loading...</div>
            :
            <div className="tempreture">
              {weather.current.temp_c} <span>C°</span>
            </div>
          }
        </div>
        : null
      }


      <div className="param">
      {   isActive &&
        <div>
          {isLoading ?
            <div></div>
            :
            <div className="wind-str">
              <span>Сила ветра:</span> {weather.current.wind_kph} <span>км/ч</span>
            </div>
          }
        </div>
      }

      {   isActive &&
        <div>
          {isLoading ?
            <div></div>
            :
            <div>
              <span>Давление:</span> {weather.current.pressure_mb} <span>Н/м²</span>
            </div>
          }
        </div>
      }
      </div>



      
        </div>

    </div>
  )
}

export default Main;