import React, {useEffect, useState} from 'react';
import './description.css'

const Descsription = () => {

  return (
    <div className='description'>
      Описание
    </div>
  );
};

export default Descsription;